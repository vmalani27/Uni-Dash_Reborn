import {
  CognitoUserPool,
  CognitoUser,
  AuthenticationDetails,
  CognitoUserAttribute,
  CognitoUserSession,
} from 'amazon-cognito-identity-js';

// Cognito configuration - update with your actual values
const COGNITO_CONFIG = {
  UserPoolId: process.env.NEXT_PUBLIC_COGNITO_USER_POOL_ID || 'null',
  ClientId: process.env.NEXT_PUBLIC_COGNITO_CLIENT_ID || "null",
  Region: process.env.NEXT_PUBLIC_COGNITO_REGION || 'us-east-1',
};

// Initialize Cognito User Pool
const userPool = new CognitoUserPool({
  UserPoolId: COGNITO_CONFIG.UserPoolId,
  ClientId: COGNITO_CONFIG.ClientId,
});

export const signUp = (email: string, password: string): Promise<any> => {
  return new Promise((resolve, reject) => {
    const attributeList: CognitoUserAttribute[] = [
      new CognitoUserAttribute({ Name: 'email', Value: email }),
    ];

    userPool.signUp(email, password, attributeList, [], (err, result) => {
      if (err) {
        reject(err);
      } else {
        resolve(result);
      }
    });
  });
};

export const confirmSignUp = (email: string, code: string): Promise<any> => {
  return new Promise((resolve, reject) => {
    const cognitoUser = new CognitoUser({
      Username: email,
      Pool: userPool,
    });

    cognitoUser.confirmRegistration(code, true, (err, result) => {
      if (err) {
        reject(err);
      } else {
        resolve(result);
      }
    });
  });
};

export const signIn = (email: string, password: string): Promise<any> => {
  return new Promise((resolve, reject) => {
    const cognitoUser = new CognitoUser({
      Username: email,
      Pool: userPool,
    });

    const authenticationDetails = new AuthenticationDetails({
      Username: email,
      Password: password,
    });

    cognitoUser.authenticateUser(authenticationDetails, {
      onSuccess: (session) => {
        cognitoUser.setSignInUserSession(session);
        resolve(session);
      },
      onFailure: (err) => {
        reject(err);
      },
    });
  });
};

export const signOut = (): void => {
  const cognitoUser = userPool.getCurrentUser();
  if (cognitoUser) {
    cognitoUser.signOut();
  }
};

export const getCurrentUser = (): CognitoUser | null => {
  return userPool.getCurrentUser();
};

export const getCurrentUserSession = (): Promise<CognitoUserSession | null> => {
  return new Promise((resolve, reject) => {
    const cognitoUser = userPool.getCurrentUser();

    if (!cognitoUser) {
      resolve(null);
      return;
    }

    cognitoUser.getSession((err: any, session: any) => {
      if (err) {
        resolve(null);
        return;
      }

      if (session && session.isValid()) {
        resolve(session);
      } else {
        resolve(null);
      }
    });
  });
};

export const getCurrentUserToken = async (): Promise<string | null> => {
  const session = await getCurrentUserSession();

  if (!session) {
    return null;
  }

  return session.getAccessToken().getJwtToken();
};

export const getCurrentUserIdToken = async (): Promise<string | null> => {
  const session = await getCurrentUserSession();

  if (!session) {
    return null;
  }

  return session.getIdToken().getJwtToken();
};

export const isUserLoggedIn = (): Promise<boolean> => {
  return new Promise((resolve) => {
    const cognitoUser = userPool.getCurrentUser();

    if (!cognitoUser) {
      resolve(false);
      return;
    }

    cognitoUser.getSession((err: any, session: any) => {
      if (err || !session || !session.isValid()) {
        resolve(false);
      } else {
        resolve(true);
      }
    });
  });
};
